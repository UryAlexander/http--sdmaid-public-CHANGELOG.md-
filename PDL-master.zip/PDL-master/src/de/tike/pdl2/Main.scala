package de.tike.pdl2

import javax.swing.WindowConstants.EXIT_ON_CLOSE
import javax.swing.{JComponent, JFrame, JOptionPane, JPanel}
import de.tike.pdl2.classes.{Snippet, Snippets}
import de.tike.pdl2.gui.{Console, Init}

object Main{
	var currSnippet: Snippet = Snippets.getIntro
	var console: Console = _
	var frame: JFrame = _
	var currentPanel: JComponent = new JPanel()
	
	def main(args: Array[String]): Unit ={
		initFrame()
		initGuiAndFail()
		initConsoleGui()
		while (currSnippet != null) currSnippet = currSnippet.weiter
		destroyGui()
	}
	
	def initFrame(): Unit ={
		frame = new JFrame()
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE)
		frame.setSize(frame.getMaximumSize)
		frame.setLocation(-10, 0)
	}
	
	def initGuiAndFail(): Unit ={
		val init = new Init()
		updatePanel(init.mainPanel)
		sleep(1000)
		val text: Array[String] = Array("") //todo
		text.foreach(t => {init.lAction.setText(t); sleep(100)})
		updatePanel(new JPanel())
		frame.setVisible(false)
		JOptionPane.showMessageDialog(frame, "Failed to initalize advanced graphics.\nFalling back to console",
			"Graphics init failed", JOptionPane.ERROR_MESSAGE)
	}
	
	def sleep(ms: Int): Unit ={
		try {
			Thread.sleep(ms)
		} catch {
			case _: InterruptedException => Thread.currentThread.interrupt()
		}
	}
	
	private def updatePanel(panel: JComponent): Unit ={
		if (panel == null) return
		frame.remove(currentPanel)
		currentPanel = panel
		// speichert das neue Panel als aktuell angezeigtes Panel
		frame.add(currentPanel)
		frame.setVisible(true)
		panel.setBounds(0, 0, frame.getWidth, frame.getHeight)
		// damit das neue Panel auch an der richtigen Stelle angezeigt wird
	}
	
	def initConsoleGui(): Unit ={
		console = new Console
		updatePanel(console.mainPanel)
	}
	
	def destroyGui(): Unit ={
		frame.setVisible(false)
		frame.dispose()
		frame = null
		System.gc()
		System.exit(0)
	}
	
	
}
