package de.tike.pdl2.classes

abstract class Effekt{
	val name: String
	val beschreibung: String
	val kannMehrmals: Boolean
	var runden: Int
	
	def anwenden(ziel: Pokemon, vorDerRunde: Boolean): Unit
	
	def getCopy: Effekt ={
		val alt = this
		new Effekt{
			override val beschreibung: String = alt.beschreibung
			override val name: String = alt.name
			override val kannMehrmals: Boolean = alt.kannMehrmals
			override var runden: Int = alt.runden
			
			override def anwenden(ziel: Pokemon, vorDerRunde: Boolean): Unit = alt.anwenden(ziel, vorDerRunde)
			
			override def hashCode(): Int = alt.hashCode()
		}
	}
	
	override def toString: String = "%s (noch %d Runden)".format(name, runden)
}
