package de.tike.pdl2.classes

import java.lang.Math.random

abstract class Attacke{
	val name: String
	val beschreibung: String
	val typ: Typ
	val schaden: Double
	val genauigkeit: Double
	val krit: Double
	val ap: Int
	var currAP: Int = ap
	val effekte: Array[Effekt]
	
	def angriff(gegner: Pokemon): Unit
	
	def standardAngriff(gegner: Pokemon): Unit = gegner.aktuelleLeben -=
		schaden * schadensfaktorTyp(gegner) * schadensFaktorAngriffVerteidigung(gegner) * schadensFaktorZufall
	
	def schadensfaktorTyp(gegner: Pokemon): Double = Typ.typenTabelle.get(typ).get(gegner.typ)
	
	def schadensFaktorAngriffVerteidigung(gegner: Pokemon): Double = schaden / Math.sqrt(gegner.rüstung)
	
	def schadensFaktorZufall: Double = 0.8 + 0.2 * random
	
	def trifft: Boolean = random < genauigkeit
	
	def istVolltreffer: Boolean = random < krit
	
	def zurückSetzen(): Unit ={
		currAP = ap
	}
}

object Attacke

