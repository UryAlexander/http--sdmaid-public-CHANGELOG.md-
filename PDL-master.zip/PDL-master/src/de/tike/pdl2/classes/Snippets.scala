package de.tike.pdl2.classes

import scala.collection.mutable.ArrayBuffer
import de.tike.pdl2.Main.console

//noinspection ScalaUnusedSymbol
object Snippets{
	private val intro: Snippet = new Snippet(){
		override val beschreibung: String = "Ich bin das Intro"
		
		override def userInteraction(): ArrayBuffer[Snippet] ={
			console.printLine("Herzlich Willkommen!")
			ArrayBuffer(test, outro)
		}
	}
	private val outro: Snippet = new Snippet(){
		override val beschreibung = "Das Ende"
		
		override def userInteraction(): ArrayBuffer[Snippet] ={
			console.printLine("So, das war's!")
			ArrayBuffer()
		}
	}
	private val test: Snippet = new Snippet{
		override val beschreibung: String = "Test"
		
		override def userInteraction(): ArrayBuffer[Snippet] ={
			console.printLine("Test")
			ArrayBuffer(test, outro)
		}
	}
	
	def getIntro: Snippet = intro
	
	
}
