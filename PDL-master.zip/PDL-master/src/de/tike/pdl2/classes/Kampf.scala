package de.tike.pdl2.classes

import de.tike.pdl2.Main.console
import de.tike.pdl2.classes.Snippet.buchstaben

class Kampf(ich: Pokemon, gegner: Pokemon){
	var gewinner: Pokemon = _
	
	def kampf(): Unit ={
		while (true) {
			runde(ich, gegner)
			if (gewonnen) return
			runde(gegner, ich)
			if (gewonnen) return
		}
	}
	
	private def runde(ich: Pokemon, gegner: Pokemon): Unit ={
		statistikenAnzeigen()
		console.printLine("%s ist dran.".format(ich.name))
		val attacke = attackeAuswählen(ich.attacken)
		console.printLine("%s benutzt %s".format(ich.name, attacke.name))
		attacke.angriff(gegner)
		if (gegner.aktuelleLeben < 0) gegner.aktuelleLeben = 0
	}
	
	def statistikenAnzeigen(): Unit ={
		def stat(pokemon: Pokemon): Unit ={
			implicit class times(x: Int){
				def times(a: Unit => Unit): Unit ={
					var n = x
					while (n > 0) {
						a.apply()
						n = n - 1
					}
				}
			}
			
			def anteil(pok: Pokemon, anz: Int = 10): Int = (anz * (pok.aktuelleLeben / pok.leben)).asInstanceOf[Int]
			
			def gegenteil(pok: Pokemon, anz: Int = 10): Int = anz - anteil(pok, anz)
			
			anteil(pokemon) times (_ => console.print("#"))
			gegenteil(pokemon) times (_ => console.print("."))
			console.printLine("")
			console.printLine(pokemon.name)
			console.printLine(pokemon.effekte.mkString("Effekte: ", ", ", ""))
		}
		
		stat(ich)
		stat(gegner)
	}
	
	def attackeAuswählen(attacken: Array[Attacke]): Attacke ={
		val gefiltert: Array[Attacke] = attacken.filter(a => a != null && (a.currAP > 0))
		gefiltert.length match {
			case 0 => null
			case 1 => attacken(0)
			case _ => var auswahl: Int = -1
				do {
					gefiltert.indices.foreach(i => console.printLine(buchstaben(i) + ": " + attacken(i).name))
					console.printLine("Bitte Wählen...")
					var char: Char = ' '
					var erfolg: Boolean = false
					do try {
						char = console.readLineFromConsole.charAt(0).toTitleCase
						erfolg = true
					} catch {
						case _: Exception =>
					} while (!erfolg)
					auswahl = if (buchstaben.contains(char)) {
						buchstaben.indexOf(char)
					} else -1
				} while (!(auswahl < attacken.length && auswahl >= 0))
				gefiltert(auswahl)
		}
	}
	
	private def gewonnen: Boolean ={
		if (ich.aktuelleLeben == 0) {
			gewinner = gegner
		} else if (gegner.aktuelleLeben == 0) {
			gewinner = ich
		} else return false
		console.printLine("%s hat gewonnen".format(gewinner.name))
		true
	}
}
