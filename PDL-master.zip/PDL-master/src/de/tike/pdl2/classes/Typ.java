package de.tike.pdl2.classes;

import java.util.HashMap;

@SuppressWarnings("ALL")
public enum Typ{
	Normal, Kampf, Flug, Gift, Boden, Gestein, Käfer, Geist, Stahl, Feuer, Wasser, Pflanze, Elektro, Psycho, Eis, Drache, Unlicht, Fee, Leer;
	private static final double p = 2;
	private static final double m = 0.5;
	private static final double x = 0;
	public static HashMap<Typ, HashMap<Typ, Double>> typenTabelle = init();
	
	private static HashMap<Typ, HashMap<Typ, Double>> init(){
		HashMap<Typ, HashMap<Typ, Double>> tmpTypenTabelle = new HashMap<>(Typ.values().length);
		// Die Map mit Standardeinträgen füllen
		for (Typ t : Typ.values()) {
			HashMap<Typ, Double> map = new HashMap<>();
			for (Typ t2 : Typ.values()) {
				map.put(t2, 1.);
			}
			tmpTypenTabelle.put(t, map);
		}
		// Spezialeinträge hinzufügen
		tmpTypenTabelle.get(Normal).put(Gestein, m);
		tmpTypenTabelle.get(Normal).put(Geist, x);
		tmpTypenTabelle.get(Normal).put(Stahl, m);
		tmpTypenTabelle.get(Kampf).put(Normal, p);
		tmpTypenTabelle.get(Kampf).put(Flug, m);
		tmpTypenTabelle.get(Kampf).put(Gift, m);
		tmpTypenTabelle.get(Kampf).put(Gestein, p);
		tmpTypenTabelle.get(Kampf).put(Käfer, m);
		tmpTypenTabelle.get(Kampf).put(Geist, x);
		tmpTypenTabelle.get(Kampf).put(Stahl, p);
		tmpTypenTabelle.get(Kampf).put(Psycho, m);
		tmpTypenTabelle.get(Kampf).put(Eis, p);
		tmpTypenTabelle.get(Kampf).put(Unlicht, m);
		tmpTypenTabelle.get(Kampf).put(Fee, m);
		tmpTypenTabelle.get(Flug).put(Kampf, p);
		tmpTypenTabelle.get(Flug).put(Gestein, m);
		tmpTypenTabelle.get(Flug).put(Käfer, p);
		tmpTypenTabelle.get(Flug).put(Stahl, m);
		tmpTypenTabelle.get(Flug).put(Wasser, p);
		tmpTypenTabelle.get(Flug).put(Elektro, m);
		tmpTypenTabelle.get(Gift).put(Gift, m);
		tmpTypenTabelle.get(Gift).put(Boden, m);
		tmpTypenTabelle.get(Gift).put(Gestein, m);
		tmpTypenTabelle.get(Gift).put(Geist, m);
		tmpTypenTabelle.get(Gift).put(Stahl, x);
		tmpTypenTabelle.get(Gift).put(Pflanze, p);
		tmpTypenTabelle.get(Boden).put(Flug, x);
		tmpTypenTabelle.get(Boden).put(Gift, p);
		tmpTypenTabelle.get(Boden).put(Gestein, p);
		tmpTypenTabelle.get(Boden).put(Käfer, m);
		tmpTypenTabelle.get(Boden).put(Stahl, p);
		tmpTypenTabelle.get(Boden).put(Feuer, p);
		tmpTypenTabelle.get(Boden).put(Pflanze, m);
		tmpTypenTabelle.get(Boden).put(Elektro, p);
		tmpTypenTabelle.get(Gestein).put(Kampf, m);
		tmpTypenTabelle.get(Gestein).put(Flug, p);
		tmpTypenTabelle.get(Gestein).put(Boden, m);
		tmpTypenTabelle.get(Gestein).put(Käfer, p);
		tmpTypenTabelle.get(Gestein).put(Stahl, m);
		tmpTypenTabelle.get(Gestein).put(Feuer, p);
		tmpTypenTabelle.get(Gestein).put(Eis, p);
		tmpTypenTabelle.get(Käfer).put(Kampf, m);
		tmpTypenTabelle.get(Käfer).put(Flug, m);
		tmpTypenTabelle.get(Käfer).put(Gift, m);
		tmpTypenTabelle.get(Käfer).put(Geist, m);
		tmpTypenTabelle.get(Käfer).put(Stahl, m);
		tmpTypenTabelle.get(Käfer).put(Feuer, m);
		tmpTypenTabelle.get(Käfer).put(Pflanze, p);
		tmpTypenTabelle.get(Käfer).put(Psycho, p);
		tmpTypenTabelle.get(Käfer).put(Unlicht, p);
		tmpTypenTabelle.get(Käfer).put(Fee, m);
		tmpTypenTabelle.get(Geist).put(Normal, x);
		tmpTypenTabelle.get(Geist).put(Geist, p);
		tmpTypenTabelle.get(Geist).put(Psycho, p);
		tmpTypenTabelle.get(Geist).put(Fee, m);
		tmpTypenTabelle.get(Stahl).put(Gestein, p);
		tmpTypenTabelle.get(Stahl).put(Stahl, m);
		tmpTypenTabelle.get(Stahl).put(Feuer, m);
		tmpTypenTabelle.get(Stahl).put(Wasser, m);
		tmpTypenTabelle.get(Stahl).put(Eis, p);
		tmpTypenTabelle.get(Stahl).put(Fee, p);
		tmpTypenTabelle.get(Feuer).put(Gestein, m);
		tmpTypenTabelle.get(Feuer).put(Käfer, p);
		tmpTypenTabelle.get(Feuer).put(Stahl, p);
		tmpTypenTabelle.get(Feuer).put(Feuer, m);
		tmpTypenTabelle.get(Feuer).put(Wasser, m);
		tmpTypenTabelle.get(Feuer).put(Pflanze, p);
		tmpTypenTabelle.get(Feuer).put(Eis, p);
		tmpTypenTabelle.get(Feuer).put(Drache, m);
		tmpTypenTabelle.get(Wasser).put(Boden, p);
		tmpTypenTabelle.get(Wasser).put(Gestein, p);
		tmpTypenTabelle.get(Wasser).put(Feuer, p);
		tmpTypenTabelle.get(Wasser).put(Wasser, m);
		tmpTypenTabelle.get(Wasser).put(Pflanze, m);
		tmpTypenTabelle.get(Wasser).put(Drache, m);
		tmpTypenTabelle.get(Pflanze).put(Flug, m);
		tmpTypenTabelle.get(Pflanze).put(Gift, m);
		tmpTypenTabelle.get(Pflanze).put(Boden, p);
		tmpTypenTabelle.get(Pflanze).put(Gestein, p);
		tmpTypenTabelle.get(Pflanze).put(Käfer, m);
		tmpTypenTabelle.get(Pflanze).put(Stahl, m);
		tmpTypenTabelle.get(Pflanze).put(Feuer, m);
		tmpTypenTabelle.get(Pflanze).put(Wasser, p);
		tmpTypenTabelle.get(Pflanze).put(Pflanze, m);
		tmpTypenTabelle.get(Pflanze).put(Drache, m);
		tmpTypenTabelle.get(Elektro).put(Flug, p);
		tmpTypenTabelle.get(Elektro).put(Boden, x);
		tmpTypenTabelle.get(Elektro).put(Wasser, p);
		tmpTypenTabelle.get(Elektro).put(Pflanze, m);
		tmpTypenTabelle.get(Elektro).put(Elektro, m);
		tmpTypenTabelle.get(Elektro).put(Drache, m);
		tmpTypenTabelle.get(Psycho).put(Kampf, p);
		tmpTypenTabelle.get(Psycho).put(Gift, p);
		tmpTypenTabelle.get(Psycho).put(Stahl, m);
		tmpTypenTabelle.get(Psycho).put(Psycho, m);
		tmpTypenTabelle.get(Eis).put(Flug, p);
		tmpTypenTabelle.get(Eis).put(Boden, p);
		tmpTypenTabelle.get(Eis).put(Stahl, m);
		tmpTypenTabelle.get(Eis).put(Feuer, m);
		tmpTypenTabelle.get(Eis).put(Wasser, m);
		tmpTypenTabelle.get(Eis).put(Pflanze, p);
		tmpTypenTabelle.get(Eis).put(Eis, m);
		tmpTypenTabelle.get(Eis).put(Drache, p);
		tmpTypenTabelle.get(Drache).put(Stahl, m);
		tmpTypenTabelle.get(Drache).put(Drache, p);
		tmpTypenTabelle.get(Unlicht).put(Kampf, m);
		tmpTypenTabelle.get(Unlicht).put(Geist, p);
		tmpTypenTabelle.get(Unlicht).put(Psycho, p);
		tmpTypenTabelle.get(Unlicht).put(Unlicht, m);
		tmpTypenTabelle.get(Unlicht).put(Fee, m);
		tmpTypenTabelle.get(Fee).put(Kampf, p);
		tmpTypenTabelle.get(Fee).put(Gift, m);
		tmpTypenTabelle.get(Fee).put(Stahl, m);
		tmpTypenTabelle.get(Fee).put(Drache, p);
		tmpTypenTabelle.get(Fee).put(Unlicht, p);
		return tmpTypenTabelle;
	}
}
