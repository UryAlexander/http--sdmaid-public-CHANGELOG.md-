package de.tike.pdl2.classes

import scala.collection.mutable.ArrayBuffer

import de.tike.pdl2.Main.console
import de.tike.pdl2.classes.Snippet.buchstaben

abstract class Snippet{
	protected val beschreibung: String
	protected var enabled = true
	protected var bestätigung = true
	
	final def weiter: Snippet = aussuchen(userInteraction())
	
	protected final def aussuchen(optionen: ArrayBuffer[Snippet]): Snippet ={
		val gefiltert: ArrayBuffer[Snippet] = optionen.filter(x => x != null && enabled)
		gefiltert.length match {
			case 0 => null
			case 1 => if (optionen(0).bestätigung) {console.print("..."); console.readLineFromConsole}
				optionen(0)
			case _ =>
				
				var auswahl: Int = -1
				do {
					gefiltert.indices.foreach(i => console.printLine(buchstaben(i) + ": " + optionen(i).beschreibung))
					console.printLine("Bitte Wählen...")
					var char: Char = ' '
					var erfolg: Boolean = false
					do try {
						char = console.readLineFromConsole.charAt(0).toTitleCase
						erfolg = true
					} catch {
						case _: Exception =>
					} while (!erfolg)
					auswahl = if (buchstaben.contains(char)) buchstaben.indexOf(char) else -1
				} while (!(auswahl < optionen.length && auswahl >= 0))
				gefiltert(auswahl)
		}
	}
	
	override def toString: String = beschreibung
	
	protected def userInteraction(): ArrayBuffer[Snippet]
}

object Snippet{
	val buchstaben: Array[Char] = ('A' to 'Z').toArray[Char]
}
