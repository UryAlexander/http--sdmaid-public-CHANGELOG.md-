package de.tike.pdl2.classes

import scala.collection.mutable.ArrayBuffer

abstract class Pokemon{
	val name: String
	val typ: Typ
	val leben: Double
	val rüstung: Double
	val attacken: Array[Attacke]
	val effekte: ArrayBuffer[Effekt] = new ArrayBuffer()
	val genauigkeit: Double = 1
	val zurückGesetzt: Unit
	var aktuelleLeben: Double = leben
	var aktuelleRüstung: Double = rüstung
	var aktuelleGenauigkeit: Double = genauigkeit
	
	def effektHinzufügen(effekt: Effekt): Unit ={
		if (effekt.kannMehrmals) effekte.append(effekt)
		val gefiltert: ArrayBuffer[Effekt] = effekte.filter(e => e.hashCode() == effekt.hashCode())
		if (gefiltert.isEmpty) effekte.append(effekt) else if (gefiltert.length == 1) {
			val index = effekte.indexOf(gefiltert(0))
			effekte(index).runden = Math.max(effekte(index).runden, effekt.runden)
		} else {
			new IllegalArgumentException(
				"Although an effect is not allowed to be applied more than once, it has been set twice or more")
				.printStackTrace()
		}
	}
	
	def zurückSetzen(): Unit ={
		aktuelleGenauigkeit = genauigkeit
		aktuelleLeben = leben
		aktuelleRüstung = rüstung
		effekte.remove(0, effekte.length)
	}
}

object Pokemon
