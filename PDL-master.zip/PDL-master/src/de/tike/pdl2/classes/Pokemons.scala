package de.tike.pdl2.classes

import java.awt.Color._
import de.tike.pdl2.Main.console

object Pokemons{
	val TiloPokemon: Pokemon = new Pokemon{
		override val name: String = "Tilo"
		override val typ: Typ = Typ.Elektro
		override val leben: Double = 1000
		override val rüstung: Double = 100
		override val zurückGesetzt: Unit = zurückSetzen()
		override val attacken: Array[Attacke] = {
			Array(new Attacke{
				override val name: String = "Tilos Geniale Attacke"
				override val beschreibung: String = "Haut den Gegner sowas von um, wenn er es am wenigsten erwartet"
				override val typ: Typ = Typ.Normal
				override val schaden: Double = 1000
				override val genauigkeit: Double = 1
				override val krit: Double = 1
				override val ap: Int = 100
				override val effekte: Array[Effekt] = {
					Array(new Effekt{
						override val beschreibung: String = "Haut den Gegner um"
						override val name: String = "ultimativer Effekt"
						override val kannMehrmals: Boolean = false
						override var runden: Int = 10
						
						override def anwenden(ziel: Pokemon, vorDerRunde: Boolean): Unit ={
							if (vorDerRunde) {
								ziel.aktuelleLeben = ziel.leben
							} else ziel.aktuelleLeben = 0
						}
					})
				}
				zurückSetzen()
				
				override def angriff(gegner: Pokemon): Unit ={
					gegner.aktuelleLeben -= schaden * schadensFaktorAngriffVerteidigung(gegner) * schadensfaktorTyp(gegner)
					effekte.foreach(gegner.effektHinzufügen)
				}
			}, new Attacke{
				override val name: String = "Tilos nicht so geniale Attacke"
				override val beschreibung: String = "Tut nichts"
				override val typ: Typ = Typ.Normal
				override val schaden: Double = 0
				override val genauigkeit: Double = 1
				override val krit: Double = 0
				override val ap: Int = 100
				override val effekte: Array[Effekt] = Array()
				zurückSetzen()
				
				override def angriff(gegner: Pokemon): Unit = console.printLine("Nichts passiert")
			}, new Attacke{
				override val name: String = "normale Attacke"
				override val beschreibung: String = "greift den Gegner ganz normal an"
				override val typ: Typ = Typ.Normal
				override val schaden: Double = 10
				override val genauigkeit: Double = 0.9
				override val krit: Double = 0.1
				override val ap: Int = 100
				override val effekte: Array[Effekt] = Array()
				zurückSetzen()
				
				override def angriff(gegner: Pokemon): Unit = standardAngriff(gegner)
				
			})
		}
	}
	val GordonSchulte: Pokemon = new Pokemon{
		override val name: String = "Herr Schulte"
		override val typ: Typ = Typ.Boden
		override val leben: Double = 400
		override val rüstung: Double = 131
		override val zurückGesetzt: Unit = zurückSetzen()
		override val attacken: Array[Attacke] = Array(new Attacke{
			override val name: String = "Totfallen"
			override val beschreibung: String = "Schüler verletzen ist im Unterricht verboten. " +
				"Da ist es gut, sein Körpergewicht einsetzen zu können. "
			override val typ: Typ = Typ.Boden
			override val schaden: Double = 0
			override val genauigkeit: Double = 0.1
			override val krit: Double = 1
			override val ap = 1
			override val effekte: Array[Effekt] = Array()
			zurückSetzen()
			
			override def angriff(gegner: Pokemon): Unit ={
				if (trifft) {
					console.printLine("%s \"stolpert\" und fällt %s K.O.".format(GordonSchulte.name, gegner.name))
					gegner.aktuelleLeben = 0
				} else {
					console.printLine("Daneben!", red)
				}
			}
		}, new Attacke{
			override val name: String = "Brüllen"
			override val beschreibung: String = "Machmal muss man die anderen einfach mal zusammenscheißen."
			override val typ: Typ = Typ.Kampf
			override val schaden: Double = 90
			override val genauigkeit: Double = 0.99
			override val krit: Double = 0.1
			override val ap: Int = 10
			override val effekte: Array[Effekt] = Array()
			zurückSetzen()
			
			override def angriff(gegner: Pokemon): Unit = standardAngriff(gegner)
			
		}, new Attacke{
			override val name: String = "Solo singen"
			override val beschreibung: String = "Ein Ständchen schleimt dich beim Gegner ein. Vielleicht verliebt er sich."
			override val typ: Typ = Typ.Kampf
			override val schaden: Double = 0
			override val genauigkeit: Double = 0.5
			override val krit: Double = 0.1
			override val ap: Int = 15
			override val effekte: Array[Effekt] = Array(new Effekt{
				override val name: String = "Verliebt"
				override val beschreibung: String = "Wer verliebt ist, greift nicht an."
				override val kannMehrmals: Boolean = false
				override var runden: Int = 10
				
				override def anwenden(ziel: Pokemon, vorDerRunde: Boolean): Unit ={
					if (vorDerRunde) {
						ziel.aktuelleGenauigkeit = 0
					}
				}
			})
			zurückSetzen()
			
			override def angriff(gegner: Pokemon): Unit ={
				if (trifft) {
					gegner.effekte.appendAll(effekte)
				} else console.printLine("Daneben", red)
			}
			
		})
	}
}
