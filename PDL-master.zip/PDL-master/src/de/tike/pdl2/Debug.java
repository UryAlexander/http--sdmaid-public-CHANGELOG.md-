package de.tike.pdl2;

public class Debug{
	@SuppressWarnings("WeakerAccess")
	public static boolean debug = true;
	
	public static boolean debug(){
		return debug;
	}
}
