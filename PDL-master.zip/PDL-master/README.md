# PDL
Pokemon der Lehrer

## TODO
- [x] Upload auf GitHub
- [ ] Leherer hinzufügen
- [ ] Story hinzufügen
- [ ] Testen

